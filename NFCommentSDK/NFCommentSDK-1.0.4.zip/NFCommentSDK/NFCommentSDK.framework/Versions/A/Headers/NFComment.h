//
//  NFComment.h
//  NFCommentSDK
//
//  Created by CaiSanze on 2018/5/11.
//

#import <Foundation/Foundation.h>

@interface NFComment : NSObject

@property (nonatomic, copy) NSString *infoId;
@property (nonatomic, copy) NSString *commentId;
@property (nonatomic, copy) NSString *userId;
@property (nonatomic, copy) NSString *userAvatar;
@property (nonatomic, copy) NSString *userNickName;
@property (nonatomic, copy) NSString *userIp;
@property (nonatomic, copy) NSString *content;
@property (nonatomic, copy) NSString *shortContent;
@property (nonatomic, assign) NSTimeInterval createdTimeInterval;

@property (nonatomic, copy) NSString *mainCommentId;
@property (nonatomic, copy) NSString *replyCommentId;
@property (nonatomic, copy) NSString *replyCommentUserId;
@property (nonatomic, copy) NSString *replyCommentUserNickName;

@property (nonatomic, copy) NSArray<NFComment *> *replys;

@property (nonatomic, assign) BOOL hideMoreContentBtn;
@property (nonatomic, assign) BOOL hideSeeAllBtn;
@property (nonatomic, assign) BOOL isTmpReplyComment;

- (instancetype)initWithDictionary:(NSDictionary *)dictionary;

+ (NSString *)shortContentWithContent:(NSString *)content;

+ (NSString *)formattedTimeWithTimeInterval:(NSTimeInterval)timeInterval;

+ (NSArray<NFComment *> *)regroupComments:(NSArray<NFComment *> *)comments;

@end
