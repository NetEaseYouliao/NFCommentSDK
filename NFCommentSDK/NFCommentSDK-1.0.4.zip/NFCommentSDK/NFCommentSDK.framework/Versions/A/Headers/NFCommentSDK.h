//
//  NFCommentSDK.h
//  NFCommentSDK
//
//  Created by CaiSanze on 2018/5/8.
//  Copyright © 2018年 NetEase. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NFCommentListViewController.h"
#import "NFCommentToolView.h"
#import "NFCommentUser.h"
#import "NFCommentNetwork.h"
#import "NFComment.h"
#import "NFCommentListInfo.h"

@interface NFCommentSDK : NSObject

/**
 初始化方法，设定appKey和appSecret
 在AppDelegate中<code>application:didFinishLaunchingWithOptions:</code>中调用

 @param appKey 应用的唯一标识，在官网申请后获取
 @param appSecret 在官网申请后获取
 */
+ (void)startWithAppKey:(NSString *)appKey appSecret:(NSString *)appSecret;

/**
 初始化评论列表页

 @param commentListInfo 列表相关请求信息
 @return NFCommentListViewController
 */
+ (NFCommentListViewController *)createCommentListViewWithCommentListInfo:(NFCommentListInfo *)commentListInfo;


/**
 初始化评论工具栏，使用默认在底部的位置
 
 @param parentVC 传入当前VC，用来添加评论工具栏以及push到评论列表页
 @param viewType 参考NFCommentToolViewType定义
 @param commentListInfo 列表相关请求信息
 @return NFCommentToolView
 */
+ (NFCommentToolView *)createCommentToolViewWithParentVC:(UIViewController *)parentVC
                                                viewType:(NFCommentToolViewType)viewType
                                         commentListInfo:(NFCommentListInfo *)commentListInfo;

/**
 更新评论的用户信息

 @param user NFCommentUser
 */
+ (void)updateCommentUser:(NFCommentUser *)user;

/**
 获取评论的用户信息

 @return NFCommentUser
 */
+ (NFCommentUser *)commentUser;

/**
 获取文章评论数量

 @param infoIds 文章IDs
 @param success 成功的block
 @param failure 失败的block
 */
+ (void)startGetCommentCountWithInfoIds:(NSArray<NSString *> *)infoIds
                                success:(responseSuccess)success
                                failure:(responseFailure)failure;

/**
 获取单篇文章评论

 @param commentListInfo 请求评论相关信息
 @param success 成功的block
 @param failure 失败的block
 */
+ (void)startGetCommentsWithCommentListInfo:(NFCommentListInfo *)commentListInfo
                                    success:(responseSuccess)success
                                    failure:(responseFailure)failure;

/**
 发布评论

 @param infoId 文章ID
 @param comment 评论信息
 @param success 成功的block
 @param failure 失败的block
 */
+ (void)startPostCommentWithInfoId:(NSString *)infoId
                           comment:(NFComment *)comment
                           success:(responseSuccess)success
                           failure:(responseFailure)failure;

@end
