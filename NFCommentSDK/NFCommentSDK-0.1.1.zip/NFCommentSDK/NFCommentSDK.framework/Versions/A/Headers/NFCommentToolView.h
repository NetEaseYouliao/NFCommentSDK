//
//  NFCommentToolView.h
//  CommentDemo
//
//  Created by menghua liu on 2018/5/8.
//  Copyright © 2018年 hih-d-11371. All rights reserved.
//

#import <UIKit/UIKit.h>

@class NFCommentToolView;

static CGFloat const NFCommentToolViewHeight = 50.f;

typedef NS_ENUM(NSInteger, NFCommentToolViewType) {
    NFCommentToolViewArticleType = 1, // 带有分享和评论数量按钮，如列表页
    NFCommentToolViewDetialType   // 无分享和评论数量按钮，如详情页
};

@protocol NFCommentToolViewDelegate <NSObject>

@optional

- (void)commentToolViewContentButtonClicked;
- (void)commentToolViewCommentButtonClicked;
- (void)commentToolViewShareButtonClicked;

@end

@interface NFCommentToolView : UIView

@property (nonatomic, weak) id <NFCommentToolViewDelegate> delegate;

@property (nonatomic, assign) NSUInteger commentCount;

@property (nonatomic, assign) NFCommentToolViewType commentToolViewType;


/**
 初始化评论工具栏，使用默认在底部的位置

 @param viewType 参考NFCommentToolViewType注释
 @return NFCommentToolView
 */
- (instancetype)initWithViewType:(NFCommentToolViewType)viewType;

/**
 初始化评论工具栏，并设置自定义位置

 @param viewType 参考NFCommentToolViewType注释
 @param position 工具栏的位置
 @return NFCommentToolView
 */
- (instancetype)initWithViewType:(NFCommentToolViewType)viewType position:(CGPoint)position;

@end
