//
//  NFCommentToolView.h
//  AFNetworking
//
//  Created by menghua liu on 2018/5/7.
//

#import <UIKit/UIKit.h>

@class NFCommentEditView;

@protocol NFCommentEditViewDelegate <NSObject>

@optional

- (void)commentEditView:(NFCommentEditView *)commentEditView didSendRequsetWithStatus:(BOOL)success;

@end

@interface NFCommentEditView : UIView

- (instancetype)initWithDelegate:(id <NFCommentEditViewDelegate>)delegate;

- (void)show;
- (void)hide;

- (void)updatePlaceholder:(NSString *)placeholder;

@end
