//
//  NFCommentListInfo.h
//  NFCommentSDK
//
//  Created by CaiSanze on 2018/6/5.
//

#import <Foundation/Foundation.h>

@interface NFCommentListInfo : NSObject

@property (nonatomic, copy) NSString *infoId;
@property (nonatomic, copy) NSString *infoTitle;
@property (nonatomic, copy) NSString *infoSource;
@property (nonatomic, assign) NSUInteger totalCommentCount;

@property (nonatomic, assign) NSUInteger pullTypeEnum;      //0：最热，1：最新，默认1
@property (nonatomic, assign) NSUInteger pageSize;          //每页数量，默认10
@property (nonatomic, assign) NSUInteger pageNo;            //第几页，默认0

@end
