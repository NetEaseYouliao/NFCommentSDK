//
//  NFCommentToolView.h
//  AFNetworking
//
//  Created by menghua liu on 2018/5/7.
//

#import <UIKit/UIKit.h>
#import "NFComment.h"

@class NFCommentEditView;
@class NFCommentListInfo;

@protocol NFCommentEditViewDelegate <NSObject>

@optional

- (BOOL)commentEditViewShouldStartSendRequest;
- (void)commentEditViewDidClickSendButton;
- (void)commentEditView:(NFCommentEditView *)commentEditView didFinishedSendRequestWithStatus:(BOOL)success comment:(NFComment *)comment;

@end

@interface NFCommentEditView : UIView

- (instancetype)initWithParentVC:(UIViewController *)parentVC delegate:(id <NFCommentEditViewDelegate>)delegate commentListInfo:(NFCommentListInfo *)commentListInfo;

- (void)showWithComment:(NFComment *)comment;
- (void)hide;

@end
