//
//  NFCommentListViewController.h
//  Pods-NFCommentSDKDemo
//
//  Created by CaiSanze on 2018/5/8.
//

#import <UIKit/UIKit.h>

@protocol NFCommentListCustomNavigationBarDelegate <NSObject>

@optional
- (void)commentListCustomNavLeftItemClicked;

@end

@interface NFCommentListViewController : UIViewController

/** 传入当前VC，用于隐藏NavigationBar以及pop到上一页面 */
@property (nonatomic, weak) UIViewController *parentVC;
/** 导航栏标题 */
@property (nonatomic, copy) NSString *navTitle;

@property (nonatomic, weak) id<NFCommentListCustomNavigationBarDelegate> customNavigationBarDelegate;

@end
