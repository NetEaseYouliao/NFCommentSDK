//
//  NFCommentToolView.h
//  CommentDemo
//
//  Created by menghua liu on 2018/5/8.
//  Copyright © 2018年 hih-d-11371. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <NFUtilityFoundation/NFShareActivity.h>
#import "NFComment.h"
#import "NFCommentListInfo.h"

@class NFCommentToolView;

@protocol NFCommentListViewCustomNavigationBarDelegate;
@protocol NFCommentListViewDelegate;

static CGFloat const NFCommentToolViewHeight = 50.f;

typedef NS_ENUM(NSInteger, NFCommentToolViewType) {
    NFCommentToolViewArticleType = 1, // 带有分享和评论数量按钮，如列表页
    NFCommentToolViewDetialType   // 无分享和评论数量按钮，如详情页
};

typedef NS_ENUM(NSInteger, NFCommentShareType) {
    NFCommentShare
};

@protocol NFCommentToolViewDelegate <NSObject>

@optional

- (void)commentToolViewDidClickShareButton;
- (void)commentToolView:(NFCommentToolView *)commentToolView didClickShareOptionWithType:(NFShareType)type;

- (void)commentToolViewDidClickCommentListButton;

- (BOOL)commentToolViewShouldStartSendRequest;
- (void)commentToolViewDidClickSendButton;
- (void)commentToolView:(NFCommentToolView *)commentToolView didFinishedSendRequestWithStatus:(BOOL)success comment:(NFComment *)comment;

@end

@interface NFCommentToolView : UIView

@property (nonatomic, weak) id <NFCommentToolViewDelegate> delegate;
@property (nonatomic, assign) NSUInteger commentCount;

@property (nonatomic, weak) id <NFCommentListViewCustomNavigationBarDelegate> commentListViewCustomNavigationDelegate;
@property (nonatomic, weak) id <NFCommentListViewDelegate> commentListViewDelegate;

- (instancetype)initWithParentVC:(UIViewController *)parentVC
                        viewType:(NFCommentToolViewType)viewType
                 commentListInfo:(NFCommentListInfo *)commmentListInfo;

- (void)showShareMenu;
- (void)showEditViewWithComment:(NFComment *)comment;

@end
