//
//  NFCommentUser.h
//  NFCommentSDK
//
//  Created by CaiSanze on 2018/6/4.
//

#import <Foundation/Foundation.h>

@interface NFCommentUser : NSObject

@property (nonatomic, copy) NSString *userId;
@property (nonatomic, copy) NSString *userNickName;
@property (nonatomic, copy) NSString *userAvatar;
@property (nonatomic, copy) NSString *userIp;

@end
