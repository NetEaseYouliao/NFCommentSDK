//
//  NFCommentSDK.h
//  NFCommentSDK
//
//  Created by CaiSanze on 2018/5/8.
//  Copyright © 2018年 NetEase. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NFCommentListViewController.h"
#import "NFCommentEditView.h"
#import "NFCommentToolView.h"

@interface NFCommentSDK : NSObject

+ (NFCommentListViewController *)createCommentListViewWithConfig:(NSDictionary *)config;

@end
