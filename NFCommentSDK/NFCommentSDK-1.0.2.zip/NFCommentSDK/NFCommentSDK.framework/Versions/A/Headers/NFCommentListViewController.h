//
//  NFCommentListViewController.h
//  Pods-NFCommentSDKDemo
//
//  Created by CaiSanze on 2018/5/8.
//

#import <UIKit/UIKit.h>
#import "NFCommentListInfo.h"

@class NFCommentListViewController;

@protocol NFCommentListViewCustomNavigationBarDelegate <NSObject>

@optional

- (void)commentListViewCustomNavLeftItemClicked;

@end

@protocol NFCommentListViewDelegate <NSObject>

@optional

- (BOOL)commentListViewShouldStartSendRequest;
- (void)commentListViewDidClickSendButton;
- (void)commentListView:(NFCommentListViewController *)commentListView didFinishSendRequestWithStatus:(BOOL)success;

- (void)commentListViewDidStartLoading;
- (void)commentListView:(NFCommentListViewController *)commentListView didFinishLoadingWithStatus:(BOOL)success;

@end

@interface NFCommentListViewController : UIViewController

/** 传入当前VC，用于隐藏NavigationBar以及pop到上一页面 */
@property (nonatomic, weak) UIViewController *parentVC;
/** 导航栏标题 */
@property (nonatomic, copy) NSString *navTitle;

@property (nonatomic, strong) NFCommentListInfo *commentListInfo;

@property (nonatomic, weak) id <NFCommentListViewCustomNavigationBarDelegate> customNavigationBarDelegate;
@property (nonatomic, weak) id <NFCommentListViewDelegate> delegate;

@end
