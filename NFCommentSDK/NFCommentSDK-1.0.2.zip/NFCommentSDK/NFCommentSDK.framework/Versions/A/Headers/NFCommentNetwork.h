//
//  NFCommentNetwork.h
//  NFCommentSDK
//
//  Created by CaiSanze on 2018/6/1.
//

#import <Foundation/Foundation.h>

typedef void(^responseSuccess)(NSDictionary *responseObject);
typedef void(^responseFailure)(NSURLSessionDataTask *task, NSError *error);

@interface NFCommentNetwork : NSObject

+ (instancetype)sharedInstance;

+ (NSString *)md5:(NSString *)str;

- (void)startPostRequestWithUrl:(NSString *)url
                         params:(NSDictionary *)params
                        success:(responseSuccess)success
                        failure:(responseFailure)failure;

@end
